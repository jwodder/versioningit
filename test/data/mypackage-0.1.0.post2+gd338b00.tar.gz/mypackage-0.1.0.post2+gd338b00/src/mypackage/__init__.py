""" A test package """

__version__ = "0.1.0.post2+gd338b00"
__version_tuple__ = (0, 1, 0, "post2", "+gd338b00")
__date__ = "2023-11-03 11:34:48+00:00"
__branch__ = 'main'
__build_date__ = "20231103T113518Z"
__commit_date__ = "2023-11-03 11:34:48+00:00"
__base_version__ = "0.1.0"
__tag_distance__ = 2
__next_version__ = "0.2.0"
__rev__ = "d338b00"
__revision__ = "d338b0080552d4ff1af9a098c2a426effcee32f0"
__vcs__ = "g"
__vcs_name__ = "git"
