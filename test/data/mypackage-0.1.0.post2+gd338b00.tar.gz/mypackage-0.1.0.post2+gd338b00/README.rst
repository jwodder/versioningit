This is a test package for testing versioningit_.

.. _versioningit: https://github.com/jwodder/versioningit
