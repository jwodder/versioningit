""" A test package """

__version__ = "0.1.0.post4+g56ed573"
__version_tuple__ = (0, 1, 0, "post4", "+g56ed573")
__date__ = "2022-06-08 19:53:46+00:00"
__branch__ = 'master'
__build_date__ = "20220612T010248Z"
__commit_date__ = "2022-06-08 20:04:41+00:00"
__base_version__ = "0.1.0"
__tag_distance__ = 4
__next_version__ = "0.2.0"
__rev__ = "56ed573"
__revision__ = "56ed573bc2524b1649ea4c45a531e920bb65b78f"
__vcs__ = "g"
__vcs_name__ = "git"
__author__ = "John Thorvald Wodder II"
__author_email__ = "mypackage@varonathe.org"
__license__ = "MIT"
