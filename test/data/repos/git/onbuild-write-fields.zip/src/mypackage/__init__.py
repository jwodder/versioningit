""" A test package """

__version__ = "NOT SET"
__author__ = "John Thorvald Wodder II"
__author_email__ = "mypackage@varonathe.org"
__license__ = "MIT"
