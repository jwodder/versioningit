""" A test package """

from ._version import version  # noqa
