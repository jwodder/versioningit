""" A test package """

__version__ = "NOT SET"
