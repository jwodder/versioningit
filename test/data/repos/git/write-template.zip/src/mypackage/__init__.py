""" A test package """

from ._version import version

__author__ = "John Thorvald Wodder II"
__author_email__ = "mypackage@varonathe.org"
__license__ = "MIT"
